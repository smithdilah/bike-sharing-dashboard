🚲 Bike Sharing Dashboard

Dashboard interaktif untuk menganalisis penggunaan sepeda berdasarkan waktu dan kondisi cuaca menggunakan Streamlit, Pandas, dan Seaborn.

1\.  📌 Fitur  
\- Filter data berdasarkan tanggal 📅  
\- Visualisasi pola penggunaan sepeda per jam ⏰  
\- Clustering waktu peminjaman sepeda (Morning Rush, Daytime, dll.) 📊  
\- Pengaruh cuaca terhadap jumlah pengguna ☀️🌧️

2\. 🛠️ Cara Menjalankan

1. Pastikan Python sudah terinstall di sistem.  
2. Install dependensi dengan:  
   \- pip install streamlit seaborn pandas matplotlib  
3. Jalankan aplikasi Streamlit dengan:  
   \- streamlit run dashboard.py

